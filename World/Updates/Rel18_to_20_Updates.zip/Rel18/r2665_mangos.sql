UPDATE creature_template SET ScriptName='npc_snufflenose_gopher' WHERE entry=4781;
