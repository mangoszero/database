UPDATE creature_template SET ScriptName='npc_dorius_stonetender' WHERE entry=8284;
