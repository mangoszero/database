DELETE FROM script_texts WHERE entry = -1070005;
INSERT INTO script_texts (entry, content_default, sound, type, language, emote, comment) VALUES
(-1070005,'%s breaks free from his stone slumber!', 0, 2, 0, 0, 'archaedas EMOTE_BREAK_FREE');
