UPDATE gameobject_template SET ScriptName='go_black_dragon_egg' WHERE entry=177807;
