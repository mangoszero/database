DELETE FROM script_texts WHERE entry=-1229020;
INSERT INTO script_texts (entry,content_default,sound,type,language,emote,comment) VALUES
(-1229020,'Intruders are destroying our eggs! Stop!!',0,1,0,0,'rookery hatcher - SAY_ROOKERY_EVENT_START');
