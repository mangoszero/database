UPDATE creature_template SET ScriptName='' WHERE entry=14822;
UPDATE creature_template SET ScriptName='' WHERE entry IN (384,1261,1460,2357,3362,3685,4730,4731,4885,7952,7955);
