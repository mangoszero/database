UPDATE creature_template SET ScriptName='npc_stinky_ignatz' WHERE entry=4880;
