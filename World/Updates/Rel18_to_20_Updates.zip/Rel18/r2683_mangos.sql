UPDATE creature_template SET ScriptName='npc_kernobee' WHERE entry=7850;
