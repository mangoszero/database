UPDATE creature_template SET ScriptName='npc_therylune' WHERE entry=3584;
