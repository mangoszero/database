RENAME TABLE `scripted_event_id` TO `scripted_event`;
