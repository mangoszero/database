UPDATE creature_template SET ScriptName='boss_zumrah' WHERE entry=7271;
