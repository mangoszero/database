UPDATE sd2_db_version SET version='ScriptDev2 (for MaNGOS z2333+) ';
