UPDATE gameobject_template SET ScriptName='go_father_flame' WHERE entry=175245;
