UPDATE creature_template SET ScriptName='npc_rabid_bear' WHERE entry=2164;
