UPDATE creature_template SET ScriptName='npc_kinelory' WHERE entry=2713;
