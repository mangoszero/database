DELETE FROM script_texts WHERE entry = -1469035;
INSERT INTO script_texts (entry, content_default, sound, type, language, emote, comment) VALUES
(-1469035,'Orb of Domination loses power and shuts off!',0,2,0,0,'razorgore EMOTE_ORB_SHUT_OFF');
