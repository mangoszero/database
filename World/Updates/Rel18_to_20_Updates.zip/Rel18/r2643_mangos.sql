UPDATE creature_template SET ScriptName='spell_dummy_npc' WHERE entry=13016;
