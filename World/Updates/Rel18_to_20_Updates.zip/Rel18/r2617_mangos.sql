DELETE FROM scripted_areatrigger WHERE entry=4752;
