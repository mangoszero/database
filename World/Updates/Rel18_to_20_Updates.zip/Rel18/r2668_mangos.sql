UPDATE gameobject_template SET ScriptName='go_sapphiron_birth' WHERE entry=181356;
