
UPDATE creature_template SET AIName='EventAI' WHERE entry=11102;
UPDATE creature_template SET AIName='EventAI' WHERE entry=15471;
UPDATE `creature` SET curmana=2486 WHERE id = 15250;


REPLACE INTO conditions VALUES (1010, 15, 51, 1);
REPLACE INTO conditions VALUES (1011, 15, 20, 1);
