UPDATE creature_template SET ScriptName='npc_captured_arkonarin' WHERE entry=11016;
