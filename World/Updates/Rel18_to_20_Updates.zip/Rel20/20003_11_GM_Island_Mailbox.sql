/*
	The fixes the GM Island mailbox, which up to this point was only usable by Alliance.
	
	Fix Author: Elarose
*/

UPDATE gameobject SET id = 144570 WHERE guid = 230922;
