DELETE FROM scripted_areatrigger WHERE entry IN (4052);
INSERT INTO scripted_areatrigger VALUES
(4052,'at_temple_ahnqiraj');
