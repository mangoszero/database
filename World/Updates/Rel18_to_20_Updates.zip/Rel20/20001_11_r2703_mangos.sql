UPDATE creature_template SET ScriptName='npc_arei' WHERE entry=9598;
