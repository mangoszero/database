UPDATE creature_template SET ScriptName='npc_shay_leafrunner' WHERE entry=7774;
