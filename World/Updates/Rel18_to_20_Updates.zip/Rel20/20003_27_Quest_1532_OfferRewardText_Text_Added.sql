/*
    This adds the ObjectRewardText text for the Shaman quest: 1532
 */
 
UPDATE quest_template SET `OfferRewardText`='For the time being. I shall give you what you need to focus your spells and to call upon the spirits of air. Take this totem, and when you are ready, train with me some more.' WHERE `entry`='1532';